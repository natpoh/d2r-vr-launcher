D2R VR launcher fixture line 00000 - the quick brown fox jumps over the lazy dog
